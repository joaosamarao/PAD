library(fclust)

data = read.csv('/Users/joaosamarao/Desktop/Mestrado_FCT/PAD/Trabalho1/metricRPackage/data_cluster.csv')
data = data[0:nrow(data),2:ncol(data)]

centers = read.csv('/Users/joaosamarao/Desktop/Mestrado_FCT/PAD/Trabalho1/metricRPackage/centers.csv')
centers = centers[0:nrow(centers),2:ncol(centers)]

membership = read.csv('/Users/joaosamarao/Desktop/Mestrado_FCT/PAD/Trabalho1/metricRPackage/membership.csv')
membership = membership[0:nrow(membership),2:ncol(membership)]

m = 2


fclust::XB(data, membership, centers, 2)
fclust::PC(membership)
fclust::PE(membership)

